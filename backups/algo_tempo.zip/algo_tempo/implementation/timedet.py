import numpy as np
from numpy import genfromtxt
import matplotlib.pyplot as plt

data=genfromtxt("filedata.out")


time = []

for i in range (len(data)):
    time.append(i)
    data[i]=data[i]/2147483648 # 32 bit diviso due (picco picco)
#print (len(data))
#print(len(time))
plt.plot(time,data)
plt.show()

start = 4668
nsamp = 256
chunk=[0]*(3*nsamp)
prog=[0]*(3*nsamp)
chunck=np.array(chunk)
for i in range(3*nsamp):
    chunk[i]=pow(data[start+i],2)
    prog[i]=i
    
plt.figure()
plt.plot(prog,chunk,'.',color='red')
plt.plot(prog,chunk)

note = genfromtxt("notes.txt")
print(note)
samples=[0]*(len(note))
for i in range(len(note)):
    samples[i]=int(round(44100./note[i]))
print(samples)
'''
plt.figure()
plt.plot(samples,note)
plt.plot(samples,note,'.',color='red')
'''
detect=0
counter=0
for i in range(len(samples)):
    passi=3*nsamp-samples[i]-2
    maxi=0.
    for j in range (passi):
        capture=(chunk[j]+chunk[j+1]+chunk[j+2]+chunk[j+samples[i]]+chunk[j+samples[i]+1]+chunk[j+samples[i]+2])/6.
        if capture > maxi:
            maxi=capture
    if maxi > detect:
        detect=maxi
        counter=i
        
print(note[counter])

# che succede se considero il quadrato dei segnali ?
# in teoria dovrei avere la risposta prima perche' considero anche quando l'onda va al minimo 
