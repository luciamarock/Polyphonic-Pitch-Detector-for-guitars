/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   streamer.h
 * Author: codac_user
 *
 * Created on April 25, 2019, 6:45 PM
 */

#ifndef STREAMER_H
#define STREAMER_H

int chunker(int buffdim, int elemcount);

#endif /* STREAMER_H */

