/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   envFollower.h
 * Author: luciamarock
 *
 * Created on August 6, 2022, 5:31 PM
 */

#ifndef FILTERS_H
#define FILTERS_H


    void rtfi_calculation(float * datartfi, float * current, int nnotes, float scaling, float * coeffA, float * coeffB, float * coeffC);



#endif /* FILTERS_H */

