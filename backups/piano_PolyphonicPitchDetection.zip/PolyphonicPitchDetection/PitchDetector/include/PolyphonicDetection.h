//
//  PolyphonicDetection.h

#ifndef PolyphonicDetection_h
#define PolyphonicDetection_h

#include <stdio.h>
#include <string>

#include "../include/resonators.h"

#define  NNOTES 89
#define NHARMS 108
#define SCALING 2147483648.0

class PolyphonicDetection {
private:
    float tet;
    float f0;
//    static const int NNOTES;
    
    float dataRTFI[NNOTES];

    float vectnote[NNOTES];

    float dataFFT[NHARMS];
    
    int num, num_items;
    float scaling;
    Tuple coefficents;
    std::string m_FilePath;
    FILE *monodet;
    FILE *integral;

public:
    int m_frames,m_samplerate,m_channels;
    float vectplot[NNOTES];

    PolyphonicDetection(int frames, int samplerate, int channels, std::string filePath);
    ~PolyphonicDetection();
    void init();
    int process(float current[]);
};

#endif /* PolyphonicDetection_h */
