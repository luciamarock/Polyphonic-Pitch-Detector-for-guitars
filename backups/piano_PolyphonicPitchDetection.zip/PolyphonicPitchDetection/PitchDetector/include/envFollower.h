/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   envFollower.h
 * Author: luciamarock
 *
 * Created on August 6, 2022, 5:31 PM
 */

#ifndef ENVFOLLOWER_H
#define ENVFOLLOWER_H


    float envelope(float * current);



#endif /* ENVFOLLOWER_H */

