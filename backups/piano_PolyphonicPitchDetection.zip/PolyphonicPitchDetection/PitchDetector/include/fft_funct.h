/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   fft_funct.h
 * Author: luciamarock
 *
 * Created on October 5, 2020, 10:43 AM
 */

#ifndef FFT_FUNCT_H
#define FFT_FUNCT_H

void fft_funct(float * current, float * datafft, int size, float tet, float f0, int nharms, int Fs);

#endif /* FFT_FUNCT_H */

