/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <fstream>
#include <iomanip>
#include "../include/filters.h"
#define sampvect 256
#define number_of_notes 89

static int init = 0;
static float pry[number_of_notes];
static float iry[number_of_notes];

void rtfi_calculation(float * datartfi, float * current, int nnotes, float scaling, float * coeffA, float * coeffB, float * coeffC){
    int k,j;
    float RTFI;
    float energy[sampvect];
    float rey[sampvect];
    float imgy[sampvect];

    if (init == 0){
        memset( pry, 0, nnotes*sizeof(int) );
        memset( iry, 0, nnotes*sizeof(int) );
        init = 1;
    }
    for (k=0; k<nnotes; ++k)
     {
         RTFI=0;
        for (j = 0; j < sampvect; ++j)
            {
            rey[j]=coeffC[k]*current[j]*scaling+coeffA[k]*pry[k]-coeffB[k]*iry[k];
            imgy[j]= coeffA[k]*iry[k]+coeffB[k]*pry[k];
            pry[k]=rey[j];
            iry[k]=imgy[j];
            energy[j]=sqrt(pow(rey[j],2)+pow(imgy[j],2));
            RTFI=RTFI+pow(energy[j],2);
            }
         RTFI=RTFI/sampvect;
         RTFI=10*log10(RTFI);

        datartfi[k] = RTFI / 170.0;
     }
}
