#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sndfile.h>
#include <unistd.h>
#include "../include/streamer.h"
#include "../include/PolyphonicDetection.h"

#define N 512

int main(int argc, char *argv[])
    {
    SNDFILE *sf;
    SF_INFO info;
    int sampvect = N/2; 
    int num, num_items;
    int *buf;
    int i,j;
    FILE *monodet;
    FILE *integral;
    // instrument - related parameters
    
    /** sf is the pointer to the .wav file, library sndfile is used to open the WAV file. */
    info.format = 0;
    const char* filePath = "../../audioFiles/piano/39.wav";
    if (argc > 1 ) {
        filePath = argv[1];
    }
    printf("input file: %s\n",filePath);
    sf = sf_open(filePath,SFM_READ,&info);
    if (sf == NULL)
        {
        printf("Failed to open the file.\n");
        exit(-1);
        }
    /* Print some of the info, and figure out how much data to read. */
    PolyphonicDetection PolyphonicDetection(info.frames,info.samplerate,info.channels,"./");
    PolyphonicDetection.init();
    num_items = info.frames*info.channels;
    printf("frames = %lld, num_items = %d \n",info.frames, num_items);

    /* Allocate space for the data to be read, then read it. */
    buf = (int *) malloc(num_items*sizeof(int));
    num = sf_read_int(sf,buf,num_items);
    printf("num = %d\n",num );
    sf_close(sf);
        
    /** nchunks is the number of chunks contained in the read audio file 
     * and it is received from function chunker() in module streamer.cpp \n
     It bases on the sampvect which is hard-coded to be 256 (N/2) samples*/
    int nchunks;        
    nchunks = chunker(sampvect,num);
    printf("nchunks = %d \n", nchunks);
    float duration = nchunks * sampvect / (float)info.samplerate;
    printf("buffer duration = %f seconds \n", duration);
    
    /* writing waveform in a file & temporal detection & envelope follower*/
    float current[sampvect];
    float integer=0.0;
    
    /* Starting the real analyzer in a loop for each chunk of the input file, when in real-time 
     * this should be the algorithm cycle which bases on each input buffer  */
    for (i=0; i<nchunks; ++i)
    {
     for (j = 0; j < sampvect; ++j)
        {
            current[j]=buf[j+(i*sampvect)]/SCALING;
        }
        PolyphonicDetection.process(current);
    }
    printf("finished analysis");
    return 0;
    }
