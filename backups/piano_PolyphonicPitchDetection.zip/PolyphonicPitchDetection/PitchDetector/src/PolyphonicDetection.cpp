
#include "../include/PolyphonicDetection.h"
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "../include/streamer.h"
#include "../include/fft_funct.h"
#include "../include/envFollower.h"
#include "../include/filters.h"
#include "../include/PolyphonicDetection.h"

#define N 512

PolyphonicDetection::PolyphonicDetection(int frames, int samplerate, int channels, std::string filePath) {
    tet  = pow(2.0, 1.0/(1.0*12.0));
    f0 = 25.9565436;
    scaling = SCALING;

    memset( dataRTFI, 0, NNOTES*sizeof(int) );
    memset( vectnote, 0, NNOTES*sizeof(int) );
    memset( vectplot, 0, NNOTES*sizeof(int) );
    memset( dataFFT, 0, NHARMS*sizeof(int) );
    m_FilePath = filePath;
    m_frames = frames;
    m_samplerate = samplerate;
    m_channels = channels;


}

void PolyphonicDetection::init() {
    if (!m_FilePath.empty()) {
        std::string str1 = m_FilePath+"/integer.out";
        std::string str2 = m_FilePath+"/monodet.out";
        integral = fopen(str1.c_str(),"w");
        monodet = fopen(str2.c_str(),"w");
    }
    /** coefficients is a tuple returned by the init function of resonators.cpp
     * the tuple contains 3 coefficents for calculating the RTFI resonators and the list
     * of notes which are the center frequency of the resonators */
    coefficents.init(m_samplerate, f0, NNOTES, tet);
}

PolyphonicDetection::~PolyphonicDetection() {
    if (!m_FilePath.empty()) {
        fclose(monodet);
        fclose(integral);
    }
}

int PolyphonicDetection::process(float current[])
    {
    int sampvect = N/2;

    float integer=0.0;

     /** Iterating on the input buffer (of dimension 256 samples) in order to build the vectors to be analyzed,
      * the real data are contained in the vector buf which represent the entire audio file; the samples of the buf
      * vector are always scaled by a factor of 2147483648 which is hard-coded \n
      
      Vector myfft_buffer[] is used for the computation of the FFT with my algorithm, it is composed by the last 4 buffers
      * thus bringing the total amount of he vector equal to 1024 samples, so the fft is calculated on this vector. The fft
      * is not really used to find the peaks, in fact we should have a calculation vector of 8192 to discriminate for real the partials
      * at lowest frequencies, but it still can be relied on to find the correct amplitudes to the partials since the RTFIs take time
      * to reflect the real amplitude of the partials. \n
      * Finally integer is used to calculate the envelope of the buffers, it gets printed on a file called integer.out */
     integer=envelope(current);
    if (!m_FilePath.empty()) {
         fprintf(integral,"%f ", integer);
         fprintf(integral,"\n");
    }
     /** Next the fft_funct() is called which calculates the fft on the same vector that is passed to */
     fft_funct(current, dataFFT, 4*sampvect, tet, f0, NHARMS, m_samplerate  );
     /** We then consider an averaged value with the former fft calculation and we print the values to the file filefft.out*/
     

    rtfi_calculation(dataRTFI, current, NNOTES, scaling, coefficents.a, coefficents.b, coefficents.c);
    // insert logic here
    for (int j = 1; j < NNOTES - 1; ++j)
    {
        if (dataRTFI[j] - dataRTFI[j-1] > 0.0 && dataRTFI[j] - dataRTFI[j + 1] > 0.0){
        vectnote[j] = dataRTFI[j];
        }
        else{
        vectnote[j] = 0.0;
        }
    }
    float avfft;
    for (int j = 0; j < NNOTES; ++j){
        if (vectnote[j] > 0.0 && j < 70){
        if (vectnote[j+12] > vectnote[j]*0.80 && vectnote[j+19] > vectnote[j]*0.80){
            avfft = (dataFFT[j] + dataFFT[j+12] + dataFFT[j+19])/3.0;
            vectplot[j] = (vectnote[j] + vectnote[j+12] + vectnote[j+19])/3.0 * avfft * 2.0;
        }
        else{
            vectplot[j] = 0.0;
        }
        }
        else{
        vectplot[j] = 0.0;
        }
        if (!m_FilePath.empty()) {
            if (j == NNOTES - 1){
            fprintf(monodet,"%f",vectplot[j]);
            fprintf(monodet,"\n");
            }
            else{
            fprintf(monodet,"%f",vectplot[j]);
            fprintf(monodet,"\t");
            }
        }
    }

    return 0;
    }

