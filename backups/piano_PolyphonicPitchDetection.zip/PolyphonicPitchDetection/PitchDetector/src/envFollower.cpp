/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <fstream>
#include <iomanip>
#include "../include/envFollower.h"
#define sampvect 256

   static float chunkmu[sampvect];
   static float chunkmd[sampvect];
   static int init = 0;

float envelope(float * current){
    int j;
    float integer = 0.0;
    if (init == 0){
    memset( chunkmu, 0, sampvect*sizeof(int) );
    memset( chunkmd, 0, sampvect*sizeof(int) );
    init = 1;
    }
    for (j=0;j<sampvect;++j){
        integer=integer+sqrt(pow(current[j],2)+pow(chunkmu[j],2)+pow(chunkmd[j],2));  // integer calculation
        chunkmd[j]=chunkmu[j];
        chunkmu[j]=current[j];
    }
    integer = integer / sampvect;
    return integer;
}
