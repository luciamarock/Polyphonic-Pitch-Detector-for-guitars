//
//  PitchDetect.swift
//  PolyDetectioniOS
//
//  Created by Gil Hadas on 09/08/2022.
//

import Foundation
import AVFoundation
import AVFAudio

class PitchDetect {
    
    var data = Data()
    var buffer:AVAudioPCMBuffer?
    var polyphonicDetectWrapper = PolyphonicDetectWrapper()
    let audioEngine  = AVAudioEngine()
    let sampleRate = 44100
    let bufferSize:UInt32 = 256
    
    func loadFile() {
        if let url = Bundle.main.url(forResource: "audioFiles/piano/39", withExtension: "wav") {
            let file = try! AVAudioFile(forReading: url)
            if let format = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: file.fileFormat.sampleRate, channels: file.fileFormat.channelCount, interleaved: false), let buf = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(file.length)) {
                    do {
                        try file.read(into: buf)
                        buffer = buf
                        // this makes a copy, you might not want that
                        let floatArray = UnsafeBufferPointer(start: buf.floatChannelData![0], count:Int(buf.frameLength))
                        // convert to data
                        for buf in floatArray {
                            data.append(withUnsafeBytes(of: buf) { Data($0) })
                        }
//                        let floatArray2 = UnsafeBufferPointer(start: buf.floatChannelData![1], count:Int(buf.frameLength))
//                        // convert to data
//                        for buf in floatArray2 {
//                            data.append(withUnsafeBytes(of: buf) { Data($0) })
//                        }

                        let paths = NSSearchPathForDirectoriesInDomains(.libraryDirectory, .userDomainMask, true)
                        
                        polyphonicDetectWrapper.initialize(UInt(floatArray.count), samplerate: Int(format.sampleRate), channels: Int(format.channelCount), filePath: paths.first)

                    } catch {
                        print(" error load wav file")
                    }
                    // use the data if required.
            }
        }
    }
    
    func start() {
        let paths = NSSearchPathForDirectoriesInDomains(.libraryDirectory, .userDomainMask, true)
        polyphonicDetectWrapper.initialize(UInt(bufferSize), samplerate: sampleRate, channels:1 , filePath: paths.first)
        requestMic()
    }
    
    func requestMic() {
        AVAudioSession.sharedInstance().requestRecordPermission {  granted in
            print("isMicGranted  \(granted)")
            if granted {
                self.startSampleFromMic()
            }
            else {
                self.loadFile()
                self.polyphonicDetectWrapper.testAudioBuffer(self.data)
            }
            DispatchQueue.main.async {
            }
        }
    }
    

     func startSampleFromMic() {
        // initialize engine
         let inputNode = audioEngine.inputNode
         let bus = 0
         inputNode.installTap(onBus: bus, bufferSize: bufferSize, format: inputNode.inputFormat(forBus:  bus)) {
             (buffer: AVAudioPCMBuffer!, time: AVAudioTime!) -> Void in
             let floatArray = UnsafeBufferPointer(start: buffer.floatChannelData![0], count:Int(buffer.frameLength))
             // convert to data
             var bufferData = Data()
             for buffer in floatArray {
                 bufferData.append(withUnsafeBytes(of: buffer) { Data($0) })
             }
             self.polyphonicDetectWrapper.process(bufferData)
         }

         do {
             audioEngine.prepare()
             try audioEngine.start()
         } catch {
             // @TODO: error out
         }
    }
}
