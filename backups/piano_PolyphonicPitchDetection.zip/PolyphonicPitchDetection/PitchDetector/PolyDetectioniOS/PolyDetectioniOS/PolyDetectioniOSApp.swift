//
//  PolyDetectioniOSApp.swift
//  PolyDetectioniOS
//
//  Created by Gil Hadas on 09/08/2022.
//

import SwiftUI

@main
struct PolyDetectioniOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
