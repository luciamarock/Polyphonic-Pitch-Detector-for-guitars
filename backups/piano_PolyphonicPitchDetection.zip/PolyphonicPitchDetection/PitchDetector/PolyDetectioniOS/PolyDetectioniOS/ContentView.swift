//
//  ContentView.swift
//  PolyDetectioniOS
//
//  Created by Gil Hadas on 09/08/2022.
//

import SwiftUI
import AVFoundation

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
    var pitchDetect = PitchDetect()
    init() {
        pitchDetect.start()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
