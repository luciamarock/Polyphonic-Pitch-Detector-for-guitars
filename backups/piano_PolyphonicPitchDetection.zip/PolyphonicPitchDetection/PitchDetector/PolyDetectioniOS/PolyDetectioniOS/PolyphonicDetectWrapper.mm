//
//  PolyphonicDetectWrapper.m
//  PolyDetectioniOS
//
//  Created by Gil Hadas on 09/08/2022.
//

#import <Foundation/Foundation.h>
#import "PolyphonicDetectWrapper.h"
#import "../../include/PolyphonicDetection.h"
#import "../../include/streamer.h"

#define N 512

@interface PolyphonicDetectWrapper ()
@end

//#import "PolyphonicDetect.h"
@implementation PolyphonicDetectWrapper

PolyphonicDetection* polyphonicDetection = nil;

- (void) initialize:(NSUInteger) frames samplerate:(NSInteger) samplerate  channels:(NSInteger) channels filePath:(NSString*) filePath {
    std::string str = std::string([filePath UTF8String]);

    polyphonicDetection = new PolyphonicDetection((int)frames,(int) samplerate, (int)channels,str);
    polyphonicDetection->init();
}

- (void) dealloc {
    delete polyphonicDetection;
}

- (void) process:(NSData*) data {
    int sampvect = N/2;
    int *buf;
    int num_items = polyphonicDetection->m_frames*polyphonicDetection->m_channels;

    buf = (int *) malloc(num_items*sizeof(int));
    [data getBytes:buf length:num_items];
    float current[sampvect];
    for (int j = 0; j < sampvect; ++j) {
        current[j]=buf[j+(sampvect)]/SCALING;
    }
    polyphonicDetection->process(current);
    [self sendToOutput];
    free(buf);
}

- (void) sendToOutput {
    bool foundResult = false;
    for (int i = 0 ; i < 89 ; i++) {
        if (polyphonicDetection->vectplot[i] > 0) {
            if (i == 0) {
                printf("sample result:\n");
            }
            foundResult = true;
            printf("index:%d, %f",i,polyphonicDetection->vectplot[i]);
        }
    }
    if (foundResult) {
        printf("\n");
    }
}

- (void) testAudioBuffer:(NSData*) data {
    int sampvect = N/2;
    int num_items = polyphonicDetection->m_frames*polyphonicDetection->m_channels;
    printf("info.frames = %d, num_items = %d \n",polyphonicDetection->m_frames, num_items);
    int *buf;
    buf = (int *) malloc(num_items*sizeof(int));
    [data getBytes:buf length:num_items];

    int nchunks;
    nchunks = chunker(sampvect,num_items);
    printf("nchunks = %d \n", nchunks);
    float duration = nchunks * sampvect / (float)polyphonicDetection->m_samplerate;
    printf("buffer duration = %f seconds \n", duration);
    
    /* writing waveform in a file & temporal detection & envelope follower*/
    float current[sampvect];
    
    /* Starting the real analyzer in a loop for each chunk of the input file, when in real-time
     * this should be the algorithm cycle which bases on each input buffer  */
    for (int i=0; i<nchunks; ++i)
    {
        for (int j = 0; j < sampvect; ++j)
        {
            current[j]=buf[j+(i*sampvect)]/SCALING;
        }
        polyphonicDetection->process(current);
        [self sendToOutput];
    }
    free(buf);
}

@end
