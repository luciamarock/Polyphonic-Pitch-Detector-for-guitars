//
//  PolyphonicDetectWrapper.h
//  PolyDetectioniOS
//
//  Created by Gil Hadas on 09/08/2022.
//

#ifndef PolyphonicDetectWrapper_h
#define PolyphonicDetectWrapper_h

#import <Foundation/Foundation.h>

@interface PolyphonicDetectWrapper : NSObject

- (void) initialize:(NSUInteger) frames samplerate:(NSInteger) samplerate  channels:(NSInteger) channels filePath:(NSString*) filePath;

- (void) process:(NSData*) data;

- (void) testAudioBuffer:(NSData*) data;
@end
#endif /* PolyphonicDetectWrapper_h */
