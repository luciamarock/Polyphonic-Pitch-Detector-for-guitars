# Readme
The local and remote code has been alligned 

# TODO
externalize the logic part (maybe) 

