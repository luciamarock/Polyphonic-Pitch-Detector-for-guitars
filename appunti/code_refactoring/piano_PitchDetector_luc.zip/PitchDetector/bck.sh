#!/bin/bash

zip -ry PitchDetector_content.zip documentation/ src/ include/ lib/ *.sh
mv PitchDetector_content.zip /home/luciamarock/Documents/OnlinePianist/Bcks

