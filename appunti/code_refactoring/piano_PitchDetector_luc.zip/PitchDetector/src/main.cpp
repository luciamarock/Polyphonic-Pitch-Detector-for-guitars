#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sndfile.h>
#include <unistd.h>
#include "../include/streamer.h"
#include "../include/resonators.h"
#include "../include/fft_funct.h"
#include "../include/envFollower.h"
#include "../include/filters.h"
#define N 512

int main()
    {
    SNDFILE *sf;
    SF_INFO info;
    int sampvect = N/2; 
    int num, num_items;
    int *buf;
    int f,sr,c;
    int i,j;
    float scaling = 2147483648.0;
    FILE *monodet;
    FILE *integral;
    // instrument - related parameters 
    float tet  = pow(2.0, 1.0/(1.0*12.0));
    float f0 = 25.9565436;   
    int nnotes = 89;  
    int nharms = 108;   

    float dataRTFI[nnotes];
    memset( dataRTFI, 0, nnotes*sizeof(int) );

    float vectnote[nnotes];
    memset( vectnote, 0, nnotes*sizeof(int) );

    float vectplot[nnotes];
    memset( vectplot, 0, nnotes*sizeof(int) );
    float dataFFT[nharms];
    memset( dataFFT, 0, nharms*sizeof(int) );
    
    /** sf is the pointer to the .wav file, library sndfile is used to open the WAV file. */
    info.format = 0;
    sf = sf_open("/home/luciamarock/Documents/AudioAnalyzer/audioFiles/piano/39.wav",SFM_READ,&info); 
    if (sf == NULL)
        {
        printf("Failed to open the file.\n");
        exit(-1);
        }
    /* Print some of the info, and figure out how much data to read. */
    f = info.frames;
    sr = info.samplerate;
    c = info.channels;
    num_items = f*c;
    
    /* Allocate space for the data to be read, then read it. */
    buf = (int *) malloc(num_items*sizeof(int));
    num = sf_read_int(sf,buf,num_items);
    sf_close(sf);
        
    /** coefficients is a tuple returned by the init function of resonators.cpp
     * the tuple contains 3 coefficents for calculating the RTFI resonators and the list 
     * of notes which are the center frequency of the resonators */
    Tuple coefficents =init(sr, f0, nnotes, tet); 
    
    /** nchunks is the number of chunks contained in the read audio file 
     * and it is received from function chunker() in module streamer.cpp \n
     It bases on the sampvect which is hard-coded to be 256 (N/2) samples*/
    int nchunks;        
    nchunks = chunker(sampvect,num);
    printf("nchunks = %d \n", nchunks);
    float duration = nchunks * sampvect / (float)sr;
    printf("buffer duration = %f seconds \n", duration);
    
    /* writing waveform in a file & temporal detection & envelope follower*/
    float current[sampvect];
    float integer=0.0;
    
    integral = fopen("integer.out","w");    
    monodet = fopen("monodet.out","w");
    

    /* Starting the real analyzer in a loop for each chunk of the input file, when in real-time 
     * this should be the algorithm cycle which bases on each input buffer  */
    for (i=0; i<nchunks; ++i)
    {
     for (j = 0; j < sampvect; ++j)
        {
            current[j]=buf[j+(i*sampvect)]/scaling;
        }

     /** Iterating on the input buffer (of dimension 256 samples) in order to build the vectors to be analyzed, 
      * the real data are contained in the vector buf which represent the entire audio file; the samples of the buf 
      * vector are always scaled by a factor of 2147483648 which is hard-coded \n 
      
      Vector myfft_buffer[] is used for the computation of the FFT with my algorithm, it is composed by the last 4 buffers 
      * thus bringing the total amount of he vector equal to 1024 samples, so the fft is calculated on this vector. The fft 
      * is not really used to find the peaks, in fact we should have a calculation vector of 8192 to discriminate for real the partials 
      * at lowest frequencies, but it still can be relied on to find the correct amplitudes to the partials since the RTFIs take time 
      * to reflect the real amplitude of the partials. \n 
      * Finally integer is used to calculate the envelope of the buffers, it gets printed on a file called integer.out */
     integer=envelope(current);
     fprintf(integral,"%f ", integer);
     fprintf(integral,"\n");
     /** Next the fft_funct() is called which calculates the fft on the same vector that is passed to */
     fft_funct(current, dataFFT, 4*sampvect, tet, f0, nharms, sr);
     /** We then consider an averaged value with the former fft calculation and we print the values to the file filefft.out*/
     

    rtfi_calculation(dataRTFI, current, nnotes, scaling, coefficents.a, coefficents.b, coefficents.c);
	// insert logic here
	for (j = 1; j < nnotes - 1; ++j)
	{
	    if (dataRTFI[j] - dataRTFI[j-1] > 0.0 && dataRTFI[j] - dataRTFI[j + 1] > 0.0){
		vectnote[j] = dataRTFI[j];
		}
	    else{
		vectnote[j] = 0.0;
		}
	}
	float avfft;
	for (j = 0; j < nnotes; ++j){
	    if (vectnote[j] > 0.0 && j < 70){
		if (vectnote[j+12] > vectnote[j]*0.80 && vectnote[j+19] > vectnote[j]*0.80){
		    avfft = (dataFFT[j] + dataFFT[j+12] + dataFFT[j+19])/3.0;
		    vectplot[j] = (vectnote[j] + vectnote[j+12] + vectnote[j+19])/3.0 * avfft * 2.0;
		}
		else{
		    vectplot[j] = 0.0;
		}
	    }
	    else{
		vectplot[j] = 0.0;
	    }
	    if (j == nnotes - 1){
		fprintf(monodet,"%f",vectplot[j]);
		fprintf(monodet,"\n");
	    }
	    else{
		fprintf(monodet,"%f",vectplot[j]);
		fprintf(monodet,"\t");
	    }
	}

    }
    fclose(monodet);
    fclose(integral);
    
    
    return 0;
    }
