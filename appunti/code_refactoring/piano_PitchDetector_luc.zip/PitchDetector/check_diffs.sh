#!/bin/bash


echo
echo /home/luciamarock/Documents/OnlinePianist/PolyphonicPitchDetection/PitchDetector/

cd src/
md5sum * ../include/* > local.log
mv local.log ../

cd /home/luciamarock/Documents/OnlinePianist/PolyphonicPitchDetection/PitchDetector/src
md5sum * ../include/* > remote.log

mv remote.log /home/luciamarock/Documents/cpp_tests/PitchDetector/

cd /home/luciamarock/Documents/cpp_tests/PitchDetector/
vimdiff local.log remote.log

