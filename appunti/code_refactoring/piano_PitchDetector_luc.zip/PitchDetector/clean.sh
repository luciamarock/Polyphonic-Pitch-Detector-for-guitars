#!/bin/bash

rm -rf local.log remote.log
echo

