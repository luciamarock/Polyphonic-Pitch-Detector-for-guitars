#!/bin/bash


cp /home/luciamarock/Documents/OnlinePianist/PolyphonicPitchDetection/PitchDetector/src/* ./src
cp /home/luciamarock/Documents/OnlinePianist/PolyphonicPitchDetection/PitchDetector/include/* ./include


